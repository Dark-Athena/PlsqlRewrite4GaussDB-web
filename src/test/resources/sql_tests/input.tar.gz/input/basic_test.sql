SELECT * FROM dual;
